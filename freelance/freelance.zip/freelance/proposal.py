# # proposal.py

# class Proposal:
#     def __init__(self, freelancer, job_post, skill_name):
#         self.freelancer = freelancer
#         self.job_post = job_post
#         self.skill_name = skill_name
#         self.accepted = None



# proposal.py
class Proposal:
    def __init__(self, freelancer, job_post, skill_name):
        self.freelancer = freelancer
        self.job_post = job_post
        self.skill_name = skill_name
        self.accepted = None
